import { template } from "./index";
export = template;
