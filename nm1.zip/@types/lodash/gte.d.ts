import { gte } from "./index";
export = gte;
