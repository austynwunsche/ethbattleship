import { isNumber } from "./index";
export = isNumber;
