import { sumBy } from "./index";
export = sumBy;
