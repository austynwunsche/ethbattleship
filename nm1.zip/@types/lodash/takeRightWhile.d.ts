import { takeRightWhile } from "./index";
export = takeRightWhile;
