import { toFinite } from "./index";
export = toFinite;
