import { min } from "./index";
export = min;
