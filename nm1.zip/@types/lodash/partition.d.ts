import { partition } from "./index";
export = partition;
