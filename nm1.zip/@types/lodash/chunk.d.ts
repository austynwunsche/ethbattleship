import { chunk } from "./index";
export = chunk;
