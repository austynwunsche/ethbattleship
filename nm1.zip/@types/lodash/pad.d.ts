import { pad } from "./index";
export = pad;
