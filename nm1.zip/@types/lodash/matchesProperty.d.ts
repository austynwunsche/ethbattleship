import { matchesProperty } from "./index";
export = matchesProperty;
