import { sortedIndex } from "./index";
export = sortedIndex;
