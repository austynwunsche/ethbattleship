import { truncate } from "../fp";
export = truncate;
