import { path } from "../fp";
export = path;
