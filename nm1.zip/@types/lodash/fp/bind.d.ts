import { bind } from "../fp";
export = bind;
