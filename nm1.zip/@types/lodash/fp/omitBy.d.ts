import { omitBy } from "../fp";
export = omitBy;
