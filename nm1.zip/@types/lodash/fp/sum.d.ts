import { sum } from "../fp";
export = sum;
