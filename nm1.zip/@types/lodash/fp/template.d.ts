import { template } from "../fp";
export = template;
