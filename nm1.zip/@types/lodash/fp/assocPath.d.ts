import { assocPath } from "../fp";
export = assocPath;
