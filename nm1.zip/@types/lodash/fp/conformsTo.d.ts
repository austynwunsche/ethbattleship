import { conformsTo } from "../fp";
export = conformsTo;
