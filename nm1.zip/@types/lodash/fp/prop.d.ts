import { prop } from "../fp";
export = prop;
