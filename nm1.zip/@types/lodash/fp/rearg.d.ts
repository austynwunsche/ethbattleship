import { rearg } from "../fp";
export = rearg;
