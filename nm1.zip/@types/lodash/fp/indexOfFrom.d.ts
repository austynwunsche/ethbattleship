import { indexOfFrom } from "../fp";
export = indexOfFrom;
