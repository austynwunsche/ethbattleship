import { property } from "../fp";
export = property;
