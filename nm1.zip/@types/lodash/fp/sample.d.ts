import { sample } from "../fp";
export = sample;
