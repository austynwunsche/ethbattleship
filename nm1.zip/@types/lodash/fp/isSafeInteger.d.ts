import { isSafeInteger } from "../fp";
export = isSafeInteger;
