import { juxt } from "../fp";
export = juxt;
