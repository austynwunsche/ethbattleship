import { split } from "../fp";
export = split;
