import { overEvery } from "../fp";
export = overEvery;
