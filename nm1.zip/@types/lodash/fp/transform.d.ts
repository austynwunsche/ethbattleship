import { transform } from "../fp";
export = transform;
