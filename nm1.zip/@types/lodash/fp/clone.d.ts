import { clone } from "../fp";
export = clone;
