import { compose } from "../fp";
export = compose;
