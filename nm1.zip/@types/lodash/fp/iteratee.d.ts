import { iteratee } from "../fp";
export = iteratee;
