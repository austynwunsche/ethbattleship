var convert = require('./convert'),
    func = convert('plant', require('../plant'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
