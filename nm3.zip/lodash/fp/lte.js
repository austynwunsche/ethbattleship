var convert = require('./convert'),
    func = convert('lte', require('../lte'));

func.placeholder = require('./placeholder');
module.exports = func;
