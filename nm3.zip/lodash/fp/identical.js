module.exports = require('./eq');
