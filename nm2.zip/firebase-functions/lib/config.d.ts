export declare function config(): config.Config;
export declare namespace config {
    type Config = {
        [key: string]: any;
    };
}
