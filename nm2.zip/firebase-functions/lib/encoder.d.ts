export declare function dateToTimestampProto(timeString?: string): {
    seconds: number;
    nanos: number;
};
