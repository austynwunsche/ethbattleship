/// <reference types="express" />
import * as express from 'express';
import * as analytics from './providers/analytics';
import * as auth from './providers/auth';
import * as crashlytics from './providers/crashlytics';
import * as database from './providers/database';
import * as firestore from './providers/firestore';
import * as https from './providers/https';
import * as pubsub from './providers/pubsub';
import * as storage from './providers/storage';
import { HttpsFunction } from './cloud-functions';
/**
 * Configure the regions that the function is deployed to.
 * @param region Region string.
 * For example: `functions.region('us-east1')`
 */
export declare function region(region: string): FunctionBuilder;
/**
 * Configure runtime options for the function.
 * @param runtimeOptions Object with 2 optional fields:
 * 1. `timeoutSeconds`: timeout for the function in seconds.
 * 2. `memory`: amount of memory to allocate to the function,
 *    possible values are:  '128MB', '256MB', '512MB', '1GB', and '2GB'.
 */
export declare function runWith(runtimeOptions: {
    timeoutSeconds?: number;
    memory?: '128MB' | '256MB' | '512MB' | '1GB' | '2GB';
}): FunctionBuilder;
export interface DeploymentOptions {
    regions?: string[];
    timeoutSeconds?: number;
    memory?: string;
}
export declare class FunctionBuilder {
    private options;
    constructor(options: DeploymentOptions);
    /**
     * Configure the regions that the function is deployed to.
     * @param region Region string.
     * For example: `functions.region('us-east1')`
     */
    region: (region: string) => this;
    /**
     * Configure runtime options for the function.
     * @param runtimeOptions Object with 2 optional fields:
     * 1. timeoutSeconds: timeout for the function in seconds.
     * 2. memory: amount of memory to allocate to the function, possible values are:
     * '128MB', '256MB', '512MB', '1GB', and '2GB'.
     */
    runWith: (runtimeOptions: {
        timeoutSeconds?: number;
        memory?: "128MB" | "256MB" | "512MB" | "1GB" | "2GB";
    }) => this;
    readonly https: {
        onRequest: (handler: (req: express.Request, resp: express.Response) => void) => HttpsFunction;
        onCall: (handler: (data: any, context: https.CallableContext) => any) => HttpsFunction;
    };
    readonly database: {
        instance: (instance: string) => database.InstanceBuilder;
        ref: (path: string) => database.RefBuilder;
    };
    readonly firestore: {
        document: (path: string) => firestore.DocumentBuilder;
        namespace: (namespace: string) => firestore.NamespaceBuilder;
        database: (database: string) => firestore.DatabaseBuilder;
    };
    readonly crashlytics: {
        issue: () => crashlytics.IssueBuilder;
    };
    readonly analytics: {
        event: (analyticsEventType: string) => analytics.AnalyticsEventBuilder;
    };
    readonly storage: {
        bucket: (bucket?: string) => storage.BucketBuilder;
        object: () => storage.ObjectBuilder;
    };
    readonly pubsub: {
        topic: (topic: string) => pubsub.TopicBuilder;
    };
    readonly auth: {
        user: () => auth.UserBuilder;
    };
}
