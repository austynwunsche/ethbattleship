// encodings/impl/base64

// TODO
